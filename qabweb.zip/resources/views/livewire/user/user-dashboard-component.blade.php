<div class="container banner header-text">
    <h1>Tablero de Usuario</h1>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Adipisci vero nobis ullam quaerat odio minima quae, cum consequatur corrupti ab pariatur eaque nemo rem repudiandae soluta, ut, minus debitis laudantium!</p>
</div>
