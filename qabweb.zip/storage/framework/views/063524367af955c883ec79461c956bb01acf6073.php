<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>QAB Reparaciones y Mantenimiento</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    
    <!--

    TemplateMo 546 Sixteen Clothing

    https://templatemo.com/tm-546-sixteen-clothing

    -->

        <!-- Additional CSS Files -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome.css')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/templatemo-sixteen.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.css')); ?>">

      </head>

      <body>

        <!-- ***** Preloader Start ***** -->
        <div id="preloader">
            <div class="jumper">
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>  
        <!-- ***** Preloader End ***** -->

        <!-- Header -->
        <header class="">
          <nav class="navbar navbar-expand-lg">
            <div class="container">
              <a class="navbar-brand" href="index.html"><h2>Sixteen <em>Clothing</em></h2></a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                  <li class="nav-item active">
                    <a class="nav-link" href="index.html">Home
                      <span class="sr-only">(current)</span>
                    </a>
                  </li> 
                  <li class="nav-item">
                    <a class="nav-link" href="products.html">Our Products</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="about.html">About Us</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="contact.html">Contact Us</a>
                  </li>
                  <?php if(Route::has('login')): ?>
                      <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->utype === 'ADM'): ?>
                        <li class="nav-item">
                          <a class="nav-link" href="#">Mi Cuenta (<?php echo e(Auth::user()->name); ?>)</a>
                        </li>
                        <li class="nav-item">
                          <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">Mi Tablero</a>
                        </li>
                        <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Cerrar Sesión')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                          </li>
                        <?php else: ?>
                        <li class="nav-item">
                          <a class="nav-link" href="#">Mi Cuenta (<?php echo e(Auth::user()->name); ?>)</a>
                        </li>
                        <li class="nav-item">
                          <a href="<?php echo e(route('user.dashboard')); ?>" class="nav-link">Mi Tablero</a>
                        </li>
                        <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Cerrar Sesión')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                          </li>
                      <?php endif; ?>
                    <?php else: ?>
                    <li class="nav-item">
                      <a href="<?php echo e(route('login')); ?>" class="nav-link">Iniciar Sesión</a>
                    </li>
                    <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                      <a href="<?php echo e(route('register')); ?>" class="nav-link">Registrarme</a>
                    </li>
                    <?php endif; ?>
                    <?php endif; ?>
                  <?php endif; ?>
                 
                </ul>
              </div>
            </div>
          </nav>
        </header>

        <!-- Page Content -->
        <!-- Banner Starts Here -->
        <div class="banner header-text">
          <div class="owl-banner owl-carousel">
            <div class="banner-item-01">
              <div class="text-content">
                <h4>Best Offer</h4>
                <h2>New Arrivals On Sale</h2>
              </div>
            </div>
            <div class="banner-item-02">
              <div class="text-content">
                <h4>Flash Deals</h4>
                <h2>Get your best products</h2>
              </div>
            </div>
            <div class="banner-item-03">
              <div class="text-content">
                <h4>Last Minute</h4>
                <h2>Grab last minute deals</h2>
              </div>
            </div>
          </div>
        </div>
        <!-- Banner Ends Here -->

        <div class="latest-products">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="section-heading">
                  <h2>Latest Products</h2>
                  <a href="products.html">view all products <i class="fa fa-angle-right"></i></a>
                </div>
              </div>
              <div class="col-md-4">
                <div class="product-item">
                  <a href="#"><img src="assets/images/product_01.jpg" alt=""></a>
                  <div class="down-content">
                    <a href="#"><h4>Tittle goes here</h4></a>
                    <h6>$25.75</h6>
                    <p>Lorem ipsume dolor sit amet, adipisicing elite. Itaque, corporis nulla aspernatur.</p>
                    <ul class="stars">
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>Reviews (24)</span>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="product-item">
                  <a href="#"><img src="assets/images/product_02.jpg" alt=""></a>
                  <div class="down-content">
                    <a href="#"><h4>Tittle goes here</h4></a>
                    <h6>$30.25</h6>
                    <p>Lorem ipsume dolor sit amet, adipisicing elite. Itaque, corporis nulla aspernatur.</p>
                    <ul class="stars">
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>Reviews (21)</span>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="product-item">
                  <a href="#"><img src="assets/images/product_03.jpg" alt=""></a>
                  <div class="down-content">
                    <a href="#"><h4>Tittle goes here</h4></a>
                    <h6>$20.45</h6>
                    <p>Sixteen Clothing is free CSS template provided by TemplateMo.</p>
                    <ul class="stars">
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>Reviews (36)</span>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="product-item">
                  <a href="#"><img src="assets/images/product_04.jpg" alt=""></a>
                  <div class="down-content">
                    <a href="#"><h4>Tittle goes here</h4></a>
                    <h6>$15.25</h6>
                    <p>Lorem ipsume dolor sit amet, adipisicing elite. Itaque, corporis nulla aspernatur.</p>
                    <ul class="stars">
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>Reviews (48)</span>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="product-item">
                  <a href="#"><img src="assets/images/product_05.jpg" alt=""></a>
                  <div class="down-content">
                    <a href="#"><h4>Tittle goes here</h4></a>
                    <h6>$12.50</h6>
                    <p>Lorem ipsume dolor sit amet, adipisicing elite. Itaque, corporis nulla aspernatur.</p>
                    <ul class="stars">
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>Reviews (16)</span>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="product-item">
                  <a href="#"><img src="assets/images/product_06.jpg" alt=""></a>
                  <div class="down-content">
                    <a href="#"><h4>Tittle goes here</h4></a>
                    <h6>$22.50</h6>
                    <p>Lorem ipsume dolor sit amet, adipisicing elite. Itaque, corporis nulla aspernatur.</p>
                    <ul class="stars">
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>Reviews (32)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="best-features">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="section-heading">
                  <h2>About Sixteen Clothing</h2>
                </div>
              </div>
              <div class="col-md-6">
                <div class="left-content">
                  <h4>Looking for the best products?</h4>
                  <p><a rel="nofollow" href="https://templatemo.com/tm-546-sixteen-clothing" target="_parent">This template</a> is free to use for your business websites. However, you have no permission to redistribute the downloadable ZIP file on any template collection website. <a rel="nofollow" href="https://templatemo.com/contact">Contact us</a> for more info.</p>
                  <ul class="featured-list">
                    <li><a href="#">Lorem ipsum dolor sit amet</a></li>
                    <li><a href="#">Consectetur an adipisicing elit</a></li>
                    <li><a href="#">It aquecorporis nulla aspernatur</a></li>
                    <li><a href="#">Corporis, omnis doloremque</a></li>
                    <li><a href="#">Non cum id reprehenderit</a></li>
                  </ul>
                  <a href="about.html" class="filled-button">Read More</a>
                </div>
              </div>
              <div class="col-md-6">
                <div class="right-image">
                  <img src="assets/images/feature-image.jpg" alt="">
                </div>
              </div>
            </div>
          </div>
        </div>


        <div class="call-to-action">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="inner-content">
                  <div class="row">
                    <div class="col-md-8">
                      <h4>Creative &amp; Unique <em>Sixteen</em> Products</h4>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque corporis amet elite author nulla.</p>
                    </div>
                    <div class="col-md-4">
                      <a href="#" class="filled-button">Purchase Now</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        
        <footer>
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="inner-content">
                  <p>Copyright &copy; 2020 Sixteen Clothing Co., Ltd.
                
                - Design: <a rel="nofollow noopener" href="https://templatemo.com" target="_blank">TemplateMo</a></p>
                </div>
              </div>
            </div>
          </div>
        </footer>


        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


        <!-- Additional Scripts -->
        <script src="assets/js/custom.js"></script>
        <script src="assets/js/owl.js"></script>
        <script src="assets/js/slick.js"></script>
        <script src="assets/js/isotope.js"></script>
        <script src="assets/js/accordions.js"></script>


        <script language = "text/Javascript"> 
          cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
          function clearField(t){                   //declaring the array outside of the
          if(! cleared[t.id]){                      // function makes it static and global
              cleared[t.id] = 1;  // you could use true and false, but that's more typing
              t.value='';         // with more chance of typos
              t.style.color='#fff';
              }
          }
        </script>


      </body>

    </html>
<?php /**PATH C:\xampp\htdocs\qabweb\resources\views//layouts/base.blade.php ENDPATH**/ ?>