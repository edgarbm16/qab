<div class="container banner header-text">
    <br>
    <br>
    <h1>Tablero de Administrador</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero debitis delectus incidunt possimus suscipit dignissimos blanditiis aliquid dolore adipisci? Adipisci sequi nulla voluptas, quisquam aliquam odit ex tempore blanditiis minima!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam aliquid eum et? Numquam consequatur, delectus labore veniam error facere iure minima. Veniam voluptatem voluptates, quas dolorum rem nihil itaque nostrum.</p>
</div>
<?php /**PATH C:\xampp\htdocs\qabweb\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>