<div>
    <div class="col-md-10 offset-md-1 col-lg-12 offset-lg-0">
        <!-- Recently Favorited -->
        <div class="widget dashboard-container my-adslist">
          <h3 class="widget-header">LISTA DE SERVICIOS</h3>
          <!-- <a class="nav-link text-white add-button" href="ad-listing.html"><i class="fa fa-plus-circle"></i> Add Listing</a> -->
          <a href="<?php echo e(route('admin.addservicio')); ?>" class="btn btn-main-sm"><i class="fa fa-plus-circle"></i> Agregar servicio</a>
          <br><br>
          <?php if(Session::has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
          <?php endif; ?>
          <table class="table table-responsive product-dashboard-table">
            <thead>
              <tr>
                <th class="text-center">ID</th>
                <th class="text-center">IMAGEN</th>
                <th class="text-center">NOMBRE DEL SERVICIO</th>
                <th class="text-center">DESCRIPCIÓN</th>
                <th class="text-center">CARACTERÍSTICAS</th>
                <th class="text-center">PRECIO</th>
                <th class="text-center">TIEMPO</th>
                <th class="text-center">ACCIONES</th>
              </tr>
            </thead>
                
            <tbody>
            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="text-center">
                    <?php echo e($servicio->id); ?>

                </td>
                <td class="text-center">
                  <img src="<?php echo e(asset('assets/images/servicios')); ?>/<?php echo e($servicio->img); ?>" width="70" >
                </td>
                <td class="text-center">
                  <?php echo e($servicio->nombre); ?>

                </td>
                <td class="text-center">
                  <?php echo e($servicio->descripcion); ?>

                </td>
                <td class="text-center">
                  <?php echo e($servicio->caracteristicas); ?>

                </td>
                <td class="text-center">
                  <?php echo e($servicio->costo); ?>

                </td>
                <td class="text-center">
                  <?php echo e($servicio->tiempo); ?>

                </td>
                <td class="action" data-title="Action">
                  <div class="">
                    <ul class="list-inline justify-content-center">
                      <li class="list-inline-item">
                        <a class="edit" data-toggle="tooltip" data-placement="top" title="Editar" href="<?php echo e(route('admin.editservicio',['servicio_slug'=>$servicio->slug])); ?>">
                          <i class="fa fa-pencil"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a class="delete" data-toggle="tooltip" data-placement="top" title="Eliminar" href="" wire:click.prevent="deleteServicio(<?php echo e($servicio->id); ?>)">
                          <i class="fa fa-trash"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
            </tbody>
          </table>
        <?php echo e($servicios->links('pagination::bootstrap-4')); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\qabweb\resources\views/livewire/admin/admin-servicio-component.blade.php ENDPATH**/ ?>