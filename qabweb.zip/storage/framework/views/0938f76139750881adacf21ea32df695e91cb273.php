<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="login py-5 border-top-1">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-8 align-item-center">
                    <div class="border border">
                        <h3 class="bg-gray p-4">CREAR TU CUENTA</h3>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <fieldset class="p-4">
                                <input type="text" placeholder="<?php echo e(__('Name')); ?>" class="border p-3 w-100 my-2" name="name" :value="old('name')" required autofocus autocomplete="name" >
                                <input type="email" placeholder="<?php echo e(__('Email')); ?>" class="border p-3 w-100 my-2" name="email" :value="old('email')" required>
                                <input type="password" placeholder="<?php echo e(__('Password')); ?>" class="border p-3 w-100 my-2" name="password" required autocomplete="new-password" >
                                <input type="password" placeholder="<?php echo e(__('Confirm Password')); ?>" class="border p-3 w-100 my-2" name="password_confirmation" required autocomplete="new-password" >
                                <div class="mt-4">
                                    <?php echo htmlFormSnippet(); ?>

                                </div>
                                <div class="loggedin-forgot d-inline-flex my-3">
                                        <!-- <input type="checkbox" id="registering" class="mt-1"> -->
                                        <!-- <label for="registering" class="px-2">By registering, you accept our <a class="text-primary font-weight-bold" href="terms-condition.html">Terms & Conditions</a></label> -->
                                        <label for="registering" class="px-2"> <a class="text-primary font-weight-bold" href="<?php echo e(route('login')); ?>"><?php echo e(__('Already registered?')); ?></a></label>
                                </div>
                                <button type="submit" class="d-block py-3 px-4 bg-primary text-white border-0 rounded font-weight-bold"> Registrar </button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\qabweb\resources\views/auth/register.blade.php ENDPATH**/ ?>