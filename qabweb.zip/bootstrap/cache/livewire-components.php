<?php return array (
  'admin.admin-add-servicio-component' => 'App\\Http\\Livewire\\Admin\\AdminAddServicioComponent',
  'admin.admin-dashboard-component' => 'App\\Http\\Livewire\\Admin\\AdminDashboardComponent',
  'admin.admin-edit-servicio-component' => 'App\\Http\\Livewire\\Admin\\AdminEditServicioComponent',
  'admin.admin-servicio-component' => 'App\\Http\\Livewire\\Admin\\AdminServicioComponent',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'servicios' => 'App\\Http\\Livewire\\Servicios',
  'user.user-dashboard-component' => 'App\\Http\\Livewire\\User\\UserDashboardComponent',
);